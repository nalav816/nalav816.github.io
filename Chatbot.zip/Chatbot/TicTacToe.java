
/**
 * Write a description of class TicTacToe here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
import java.util.ArrayList;
public class TicTacToe
{
    // instance variables - replace the example below with your own
    private int offsetX, offsetY; //in spaces
    char[] symbols = {'-', '-', '-', '-', '-', '-', '-', '-', '-'}; //stores an empty table for storing tic tac toe chars. '-' is our null value.
    char[] possibleSymbols = {'X', 'O'}; //Holds symbols which can be assigned to player or bot
    public char playerSymbol, botSymbol;
    
    /**
     * Constructor for objects of class TicTacToe
     */
    public TicTacToe()
    {
        assignSymbols();
    }
    
    public void play(int moveChoice){ //Player makes move through this function
        addSymbol(playerSymbol, moveChoice);
        drawBoard();
        
    }
    
    public int playMoveBot(){ //Bot plays move and returns square they played
        ArrayList<Integer> unoccupiedSlots = getSpots('-'); //Gets a list of unoccupied squares
        int random = unoccupiedSlots.get(getRandom(0,unoccupiedSlots.size()-1)); //Choose random square
        
        addSymbol(botSymbol, random);
        drawBoard();
        
        return random;
    }
    
    public void drawBoard(){
        for(int row = 1; row <= 9; row++){
            System.out.println("");
            if(row == 3 || row == 6){ //Rows with row dividers
                for(int i = 0; i < 11; i++){
                    if(i == 3 || i == 7){ //Draws column divide
                        System.out.print("|");
                    }else{ //Draws row divider
                        System.out.print("_");
                    }
                    System.out.print(" ");
                }
            }else if(row == 2 || row == 5 || row == 8){
                 for(int i = 0; i < 20; i++){
                    if(i == 6  || i == 14){ //Draws border line
                        System.out.print("|");
                    }else if(i == 2){ //Space
                        drawSymbol(1 + (row-2)); //Formula for calculating numbeer
                    }else if (i == 10){
                        drawSymbol(2 + (row-2));
                    }else if(i == 18){
                        drawSymbol(3 + (row-2));
                    }else{
                        System.out.print(" ");
                    }
                }
            
            }else{ //Rows with no row dividers
                for(int i = 0; i < 20; i++){
                    if(i == 6  || i == 14){ //Draws border line
                        System.out.print("|");
                    }else{ //Space
                        System.out.print(" ");
                    }
                }
            }
        }
        
        //Double spaces any text that comes after
        System.out.println("");
        System.out.println("");
    }
    
    public void resetGame(){
        char[] newArray = {'-','-', '-', '-', '-', '-', '-', '-', '-'};
        symbols = newArray;
        assignSymbols();
    }
    
    public void assignSymbols(){ //Randomly assigns symbol to character and bot
        int random = getRandom(0, 1);
        playerSymbol = possibleSymbols[random];
        
        if(random == 1){
            botSymbol = possibleSymbols[0];
        }else{
            botSymbol = possibleSymbols[1];
        }
    }
    
    //adds symbol to tic tac toe board
    public void addSymbol(char symbol, int square){
        symbols[square - 1] = symbol;
    }
    
    public void drawSymbol(int square){ //Each square in tic tac toe will be numbered 1-9. Draws a symbol if there is one in the corresponding spot in the array
        if(symbols[square - 1] != '-'){
            System.out.print(symbols[square - 1]);
        }else{
            System.out.print(square);
        }
        
    }
    
    public ArrayList<Integer> getSpots(char symbol){ //Gets the spots a certain symbol occupies. This is so we can tell where the xs and os are as well as where is unoccupied.
        ArrayList<Integer>occupiedSpots = new ArrayList<Integer>();
        for(int i = 0; i < symbols.length; i++){
            if(symbols[i] == symbol){
                occupiedSpots.add(i + 1); //Plus one because tictactoe squares are stored from 1-9
            }
        }
        
        return occupiedSpots;
    }
    
    
    public boolean playerWon(){ //Checks if player won
        return checkWinCondition(getSpots(playerSymbol));
    }
    
    public boolean botWon(){ //Checks if bot won
        return checkWinCondition(getSpots(botSymbol));
    }
    
    public boolean isTie(){ //Checks for tie. 
        if(getSpots('-').size() == 0 && !playerWon() && !botWon()){
            return true;
        }else{
            return false;
        }
    }
    
    private boolean checkWinCondition(ArrayList<Integer> squares){ //Uses patterns to figure out if there is a three in a row and returns which symbol if there is
         /* RULES
         * 1) Horizontal = Three numbers in same row
         * 2) Vertical = Three numbers in same column
         * 3) Diagnol = If there is a sequence of numbers that are diagnol to each other, they would add up to 15 AND that set of numbers would have to include 5
         */
        for(int i = 0; i < squares.size(); i++){
            int sharedRows = 0; //Keeps track of how many other numbers in the dataset share row
            int sharedColumns = 0; //Keeps track of how many other numbers in the dataset share column
            int diagnolNumber = 15 - (squares.get(i) + 5); //This is for the diagnol line test. In order for it to be a diagnol three in row, the other number must be equal to this and 5(the middle must be occupied)
            boolean diagnolTestPassed = false;
            for(int other = 0; other < squares.size(); other++){
                if(other != i){ //So it doesn't happen for the same square
                    int num = squares.get(i); //The actual square value
                    int otherNum = squares.get(other);
                    //Checks shared row
                    if(getRow(num) == getRow(otherNum)){
                        sharedRows ++;
                    }
                    
                    //Checks shared column
                    if(getColumn(num, getRow(num)) == getColumn(otherNum, getRow(otherNum))){
                        sharedColumns ++;
                    }
                   
                    //Diagnol line test
                    if(diagnolNumber == otherNum && squares.indexOf(5) != -1){
                        diagnolTestPassed = true;
                    }
                }
            }
            
            if(sharedRows == 2 || sharedColumns == 2 || diagnolTestPassed){
                return true;
            }
        }
        
        return false;
    }
    
    private int getRow(int square){ //Returns row a square is on
        return (int) Math.floor(square/3.01) + 1;
    }
    
    private int getColumn(int square, int row){ //Returns column a square is on
        return square - (3*(row-1));
    }
    
    private int getRandom(int min, int max){ //Same random function in other classes
       int outcome = (int) Math.floor(Math.random() * (max+1-min) + min); 
       return outcome;
    }
}
