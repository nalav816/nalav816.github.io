
/**
 * Write a description of class RockPaperScizzors here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class RockPaperScissors
{
    // instance variables - replace the example below with your own
    private int mode;
    private String[] moves = {"rock", "paper", "scissors"};
    public String botMove, playerMove;

    /**
     * Constructor for objects of class RockPaperScizzors
     */
   RockPaperScissors(int newMode)
    {
        
        mode = newMode;
    }
    
    public String play(String userInput){
        userInput = userInput.toLowerCase();
        //takes intended move from users string. If they say multiple moves for some reason, rock will be prioritized, then paper, then scissors.
        if(userInput.contains("rock")){
            playerMove = "rock";
        }else if(userInput.contains("paper")){
            playerMove = "paper";
        }else{
            playerMove = "scissors";
        }
        
        
        if(mode == 1){ //Mode one is troll mode and the bot will automatically win every game
            botMove = getBestMove();
            return matchOutcome(botMove, playerMove);
        }else{ //Bot chooses randoms moves
            botMove = moves[getRandom(0,2)];
            return matchOutcome(botMove, playerMove);
        }
    }
    
    private String getBestMove(){ //Returns "top engine" move.
        for(int i = 0; i < 3; i++){

            if(matchOutcome(moves[i], playerMove).equals("I win!")){
                return moves[i];
            }
        }
        return "Hi";
    }
    
    private String matchOutcome(String botMove, String playerMove){ //Returns match outcome from the perspective of the bot
        if((botMove == "paper" && playerMove == "rock") || (botMove == "rock" && playerMove == "scissors") || (botMove == "scissors" && playerMove == "paper")){
            return "I win!";
        }else if(botMove.equals(playerMove)){
            return "We tied!";
        }else{
            return "I lost!";
        }
    }
    
    private int getRandom(int min, int max){ //Gives random number
       int outcome = (int) Math.floor(Math.random() * (max+1-min) + min); 
       return outcome;
    }

    
}
