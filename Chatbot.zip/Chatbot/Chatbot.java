
import java.util.Scanner;
import java.util.ArrayList;

public class Chatbot
{
    ///VARIABLES///
    //Objects
    private static Scanner userInput = new Scanner(System.in);
    
    //Settings
    private static int invalidResponses; //This only counts chars with messages that have no valid charracters, not messages the computer cant interpret. I have this as a variable so I can shut down bot after too many.
    private static int maxInvalidResponses;
    private static ResponseLibrary library;
    
    public static void main(String[] args){
        ///VARIABLES///
        
        //Response variables
        invalidResponses = 0;
        maxInvalidResponses = 5;
        
        //Response library holds all key words and bot error responses
        library = new ResponseLibrary();
       
       ///CHATBOT ASKS NAME///
       String name = getName(type("Hi! I'm GameBot, what is your name?", true));
       
       ///CHATBOT ASKS FEELINGS///
       String response = type("Nice to meet you " + name + ". How are you feeling?", true).toLowerCase(); //I didnt put this function in my type() because there are situations where I may not want it
       String[] outcome = getResponseType(response, library.affirmativeFeelings, library.negativeFeelings, library.feelingErrorMessages);
      
       if(outcome == library.affirmativeFeelings){
           type("That's good to hear!", false);
           response = type("However, I know what could make you even better! Wanna play a game?", true).toLowerCase();
       }else{
           type("That sucks. Unfortunately for you I can't really relate because I am a robot.", false);
           response = type("However, I know what might cheer you up. Wanna play a game?", true).toLowerCase();
        }
        
        ///CHATBOT ASKS IF YOU WANT TO PLAY GAME///
       outcome = getResponseType(response, library.affirmatives, library.negatives, library.yesOrNoErrorMessages);
       
       if(outcome == library.affirmatives){
           response = type("Which game would you like to play? I can play tic tac toe or rock paper scissors.", true).toLowerCase();
           outcome = getResponseType(response, library.rockPaperScissors, library.ticTacToe, library.gameInquiryErrorMessages);
           
           if(outcome == library.rockPaperScissors){
               ///ROCK PAPER SCISSORS GAME///
               boolean gameActive = true;
               int playerScore = 0;
               int botScore = 0;
               RockPaperScissors newGame = new RockPaperScissors(randomInt(1, 2)); //The paramater chooses a random mode
               type("Okay! Let's play best of three.", false);
               while(gameActive){
                   response = validateSpecificResponse(type("What move would you like to play?", true), library.rockPaperScissors, library.rockPaperScissors, library.rockPaperScissorError); 
                   String gameOutcome = newGame.play(response); //stores who wins
                   String botMove = newGame.botMove;
                   String playerMove = newGame.playerMove;
                   
                   type("I played " + botMove + " and you played " + playerMove + ". " + gameOutcome, false);
                   
                   if(gameOutcome.equals("I win!")){
                       botScore ++;
                   }else if(gameOutcome.equals("I lost!")){
                       playerScore ++;
                   }
                   
                   if(playerScore == 2){ //Victory message
                       type("Wow. Crazy. You won. No skill. Only luck.", false);
                   }else if(botScore == 2){ //loser message
                       type("Haha! You suck! Get good.", false);
                   }
                   
                   if(botScore == 2 || playerScore == 2){ //When game ends
                       outcome = getResponseType(type("Would you like to play again?", true), library.affirmatives, library.negatives, library.yesOrNoErrorMessages);
                       if(outcome == library.affirmatives){
                           type("Bet!", false);
                           botScore = 0;
                           playerScore = 0;
                       }else{ //Ends game if player says no
                           type("Okay, that is fair. I had a fun time, cya!", false);
                           gameActive = false;
                       }
                   }
               }
               
               
           }else{
               ///TIC TAC TOE GAME///
               TicTacToe newGame = new TicTacToe();
               newGame.drawBoard();
               boolean gameActive = true;
               while(gameActive){
                   int moveChoice = validateTicTacToeResponse(type("What move would you like to play (" + newGame.playerSymbol + ")? Choose the number which corresponds with your desired square.", true), newGame.getSpots('-'));
                   newGame.play(moveChoice); //Player move
                   
                   //Win message
                   if(newGame.playerWon()){
                       type("Wow three in a row, congratulations! Congratualtions because you got lucky, not because there was any skill involved.", false);
                   }else{
                       //Bot move
                       if(newGame.getSpots('-').size() > 0){ //only move bot if there is moves left to play
                            type("Cool! I played square number " + newGame.playMoveBot() + ".", false);
                        }
                    }
                   
                   //Lose message
                   if(newGame.botWon()){
                       type("You need to do better. You just lost to a bot that is straight up putting symbols in random places.", false);
                   }
                   
                   //Tie message
                   if(newGame.isTie()){
                       type("Wow we tied! Now we gotta go again to settle the score.", false);
                   }
                   
                   if(newGame.botWon() || newGame.playerWon() || newGame.isTie()){
                       outcome = getResponseType(type("Again?", true), library.affirmatives, library.negatives, library.yesOrNoErrorMessages);
                       if(outcome == library.affirmatives){
                           type("Yay!", false);
                           newGame.resetGame();
                           newGame.drawBoard();
                       }else{ //Ends game if player says no
                           type("Alright, maybe another time. Goodbye!", false);
                           gameActive = false;
                       }
                   }
                   
                }
           }
       }else{
            type("Fine! Be like that!", false); //Thread ends here;
        }
        
    }
    
    //Chatbot types messages using typewriter effect and checks for a generally valid response
    //The typewriter effect isn't entirely fool proof since you can still input while the program is typing but it works for the scope of this project
    private static String type(String text, boolean expectingResponse){
        int typeSpeed = 8;
        int counter = 0;
        
        while (counter < text.length()){
            
            System.out.print(text.substring(counter, counter+1));
            try{ 
                Thread.sleep(100/typeSpeed); //Wait a bit to make typewriter
            }catch (Exception error){
                System.out.println(error);
            }
            counter++;

        }
       
        System.out.println("");
        
        if(expectingResponse){
            String response = userInput.nextLine();
            if(!validResponse(response)){  //Accounts for edge case where only spaces or special characters are typed
                //Possible responses for whenever you try to cheese the system.
                String[] possibleResponses = {"Please actually type something. Will you? For me?",
                    "Come on now do better. I know you're trying to break me but it wont happen.",
                    "I see, I'll be here whenever you actually decide to say something valid."};
    
                if(invalidResponses < maxInvalidResponses - 1){
                    //Uses recursion if user types only spaces
                    return type(possibleResponses[invalidResponses - 1], true);
                }else if(invalidResponses == maxInvalidResponses - 1){
                    //Warning
                    type("Do it one more time, I dare you!", true);
                }else{
                    //Exits program
                    type("I'm tired of you, goodbye!", false);
                    System.exit(0); //https://stackoverflow.com/questions/45114434/how-to-exit-java-window-after-a-command-in-blue-j
                }
            }
            
            return response;
        }
    
        return null;
    }
    
     //Validates response by repeating a scanner loop until you type in something that contains a key word from either array and returns the new response.
    private static String validateSpecificResponse(String response, String[] validStringsOne, String[] validStringsTwo, String[] errorMessages){
        while(!library.stringContainsArray(validStringsOne, response) && !library.stringContainsArray(validStringsTwo, response)){
            response  = type(chooseRandomResponse(errorMessages), true);
        }
        
        return response;
    }
    
    //Had to make a seperate function for this since it deals with arraylist and numbers instead. Also it returns an int since its indicating where you want to draw your symbol 
    private static int validateTicTacToeResponse(String response, ArrayList<Integer> availableSpots){
        int num = 0;
        try{
            num = Integer.parseInt(response);
        }catch(Exception error){ //If the top line errors, it means the user has not typed in the number and the function needs to be fired again
            response = type("You need to type in a number.", true);
            return validateTicTacToeResponse(response, availableSpots);
        }
        
        if(availableSpots.indexOf(num) == -1){ //If the number cannot be found in the available spot list, it's invalid.
            response = type("The number you have typed is invalid.", true);
            return validateTicTacToeResponse(response, availableSpots);
        }
        
        return num;        
    }
    
    /*This function returns the array which the key word was found for after validating it. 
    */
    private static String[] getResponseType(String response, String[] validStringsOne, String[] validStringsTwo, String[] errorMessages){
       //Validates response
        String newResponse = validateSpecificResponse( response,  validStringsOne,  validStringsTwo,  errorMessages);
        //Returns array
        if(library.stringContainsArray(validStringsOne, newResponse)){ //if they are both in string, first array has priority
           return validStringsOne;
        }else{
           return validStringsTwo;
        }
    }
    
   private static String getName(String input){ //Gets last word in input string since names are generally the last thing you say when introducing yourself
        input = input.trim();
        String name = "";
        for(int i = input.length() - 1; i >= 0; i--){  //Iterates through the string backwards to grab last word
            if(input.charAt(i) != ' '){
                name = input.charAt(i) + name;
            }else{
                break;
            }
        }
        
        return name;
    }
    
    private static boolean validResponse(String response){
        //Checks if response contains letters or digit, otherwise its invalid
        for(int i = 0; i < response.length(); i++){
            char input = response.charAt(i);
            
            if(Character.isLetter(input) || Character.isDigit(input)){
                return true;
            }
        }
        
        invalidResponses++;
        return false;
    }
    
    //Chooses a random string from a string array
    private static String chooseRandomResponse(String[] responses){
        return responses[randomInt(0, responses.length - 1)];
    }
    
    //Returns random number in given range
    private static int randomInt(int min, int max){ //Both are inclusive
    //source: https://developer.mozilla.org/en-US/docs/Web/JavaScript/Reference/Global_Objects/Math/random
       int outcome = (int) Math.floor(Math.random() * (max+1-min) + min); 
       return outcome;
    }

    
}
