
/**
 * Write a description of class ResponseLibrary here.
 *
 * @author (your name)
 * @version (a version number or a date)
 */
public class ResponseLibrary ///THIS CLASS STORES ALL STRING ARRAYS
{
    ///RESPONSE LIBRARY///
    ///USER RESPONSES
    //YES-NO
    String[] affirmatives = {"yes", "sure", "okay"};
    String[] negatives = {"no", "nah"};
       
    //FEELINGs
    String[] affirmativeFeelings = {"good", "okay", "great", "fine"};
    String[] negativeFeelings = {"bad", "trash", "sad", "terrible", "tired"};
    
    //GAME REFERENCES
    String[] rockPaperScissors = {"rock", "paper", "scissor"};
    String[] ticTacToe = {"tic", "tac", "toe"};
    
    ///BOT RESPONSES
    String[] feelingErrorMessages = {"Please speak so a bunch of 1s and 0s can understand.", "Tell me how your feeling, not your whole life's story!"};
    String[] yesOrNoErrorMessages = {"It's a yes or no question, cmon now!", "I see, maybe phrase it so I can understand."};
    String[] gameInquiryErrorMessages = {"Choose a game already!", "I can't understand what you are saying."};
    String[] rockPaperScissorError = {"Type either rock, paper, or scissors."};
    
    
    //Checks if any word in an array is found within a string
    public boolean stringContainsArray(String[] array, String stringToCheck){ //Checks if string contains any word in array
        for(int i = 0; i < array.length; i++){
            if(stringToCheck.toLowerCase().contains(array[i])){
                return true;
            }
        }
        return false;
    }
    
       
}
